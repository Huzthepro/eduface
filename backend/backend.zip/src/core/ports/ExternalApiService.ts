export interface ExternalApiService {
  fetchJobApplications(): Promise<any[]>;
}
