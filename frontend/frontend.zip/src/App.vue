<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'RootApp',
})
</script>

<template>
  <router-view />
</template>

<style></style>
